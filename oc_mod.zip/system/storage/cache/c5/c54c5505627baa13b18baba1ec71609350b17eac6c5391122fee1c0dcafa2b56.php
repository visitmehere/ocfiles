<?php

/* extension/module/octhemeoption.twig */
class __TwigTemplate_a49d59e8595da3f8930fd4d9aa438360e82dbcac0d37eae3dd54d91f58bd5216 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo (isset($context["header"]) ? $context["header"] : null);
        echo (isset($context["column_left"]) ? $context["column_left"] : null);
        echo "
<div id=\"content\">
    <div class=\"page-header\">
        <div class=\"container-fluid\">
            <div class=\"pull-right\">
                <button type=\"submit\" form=\"form-octhemeoption\" data-toggle=\"tooltip\" title=\"";
        // line 6
        echo (isset($context["button_save"]) ? $context["button_save"] : null);
        echo "\" class=\"btn btn-primary\"><i class=\"fa fa-save\"></i></button>
                <a href=\"";
        // line 7
        echo (isset($context["cancel"]) ? $context["cancel"] : null);
        echo "\" data-toggle=\"tooltip\" title=\"";
        echo (isset($context["button_cancel"]) ? $context["button_cancel"] : null);
        echo "\" class=\"btn btn-default\"><i class=\"fa fa-reply\"></i></a></div>
            <h1>";
        // line 8
        echo (isset($context["heading_title"]) ? $context["heading_title"] : null);
        echo "</h1>
            <ul class=\"breadcrumb\">
                ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["breadcrumbs"]) ? $context["breadcrumbs"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["breadcrumb"]) {
            // line 11
            echo "                    <li><a href=\"";
            echo $this->getAttribute($context["breadcrumb"], "href", array());
            echo "\">";
            echo $this->getAttribute($context["breadcrumb"], "text", array());
            echo "</a></li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['breadcrumb'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "            </ul>
        </div>
    </div>
    <div class=\"container-fluid\">
        ";
        // line 17
        if ((isset($context["error_warning"]) ? $context["error_warning"] : null)) {
            // line 18
            echo "            <div class=\"alert alert-danger\"><i class=\"fa fa-exclamation-circle\"></i> ";
            echo (isset($context["error_warning"]) ? $context["error_warning"] : null);
            echo "
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>
            </div>
        ";
        }
        // line 22
        echo "        ";
        if ((isset($context["error_load_file"]) ? $context["error_load_file"] : null)) {
            // line 23
            echo "            <div class=\"alert alert-danger\"><i class=\"fa fa-exclamation-circle\"></i> ";
            echo (isset($context["error_load_file"]) ? $context["error_load_file"] : null);
            echo "
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>
            </div>
        ";
        }
        // line 27
        echo "        ";
        if ((isset($context["success"]) ? $context["success"] : null)) {
            // line 28
            echo "            <div class=\"alert alert-success alert-dismissible\"><i class=\"fa fa-check-circle\"></i> ";
            echo (isset($context["success"]) ? $context["success"] : null);
            echo "
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>
            </div>
        ";
        }
        // line 32
        echo "        <div class=\"panel panel-default\">
            <div class=\"panel-heading\">
                <h3 class=\"panel-title\"><i class=\"fa fa-pencil\"></i>";
        // line 34
        echo (isset($context["text_edit"]) ? $context["text_edit"] : null);
        echo "</h3>
            </div>
            <div class=\"panel-body\">
                <form action=\"";
        // line 37
        echo (isset($context["action_import"]) ? $context["action_import"] : null);
        echo "\" method=\"post\" enctype=\"multipart/form-data\" id=\"form-data\" class=\"form-horizontal\">
                    <input type=\"hidden\" name=\"file\" />
                </form>

                <form action=\"";
        // line 41
        echo (isset($context["action"]) ? $context["action"] : null);
        echo "\" method=\"post\" enctype=\"multipart/form-data\" id=\"form-octhemeoption\" class=\"form-horizontal\">
                    <ul class=\"nav nav-tabs\">
                        <li class=\"active\"><a href=\"#tab-stylesheet\" data-toggle=\"tab\">";
        // line 43
        echo (isset($context["tab_stylesheet"]) ? $context["tab_stylesheet"] : null);
        echo "</a></li>
                        <li><a href=\"#tab-configuration\" data-toggle=\"tab\">";
        // line 44
        echo (isset($context["tab_configuration"]) ? $context["tab_configuration"] : null);
        echo "</a></li>
                        <li><a href=\"#tab-database\" data-toggle=\"tab\">";
        // line 45
        echo (isset($context["tab_backup"]) ? $context["tab_backup"] : null);
        echo "</a></li>
                    </ul>

                    <div class=\"tab-content\">
                        <div class=\"tab-pane active\" id=\"tab-stylesheet\">
                            <div class=\"form-group\">
                                <label class=\"col-sm-2 control-label\" for=\"input-stylesheet-store\">";
        // line 51
        echo (isset($context["entry_store"]) ? $context["entry_store"] : null);
        echo "</label>
                                <div class=\"col-sm-6\">
                                    <select id=\"input-stylesheet-store\" class=\"form-control\">
                                        ";
        // line 54
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["stores"]) ? $context["stores"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["store"]) {
            // line 55
            echo "                                            <option value=\"";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" ";
            if (($this->getAttribute($context["store"], "store_id", array()) == 0)) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo $this->getAttribute($context["store"], "name", array());
            echo "</option>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['store'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                                    </select>
                                </div>
                            </div>

                            ";
        // line 61
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["stores"]) ? $context["stores"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["store"]) {
            // line 62
            echo "                            <div id=\"frm-stylesheet-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"frm-stylesheet\">
                                <div class=\"form-group\">
                                    <label class=\"col-sm-2 control-label\" for=\"input-status-";
            // line 64
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">";
            echo (isset($context["entry_status"]) ? $context["entry_status"] : null);
            echo "</label>
                                    <div class=\"col-sm-6\">
                                        <select name=\"module_octhemeoption_status[";
            // line 66
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "]\" id=\"input-status-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-id=\"";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"form-control style-status\">
                                            ";
            // line 67
            if ($this->getAttribute((isset($context["module_octhemeoption_status"]) ? $context["module_octhemeoption_status"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array")) {
                // line 68
                echo "                                                <option value=\"1\" selected=\"selected\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\">";
                // line 69
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            } else {
                // line 71
                echo "                                                <option value=\"1\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\" selected=\"selected\">";
                // line 72
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            }
            // line 74
            echo "                                        </select>
                                    </div>
                                </div>

                                <div class=\"row stylesheet-settings\" id=\"stylesheet-settings-";
            // line 78
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                    <div class=\"col-sm-2\">
                                        <ul class=\"nav nav-pills nav-stacked\" id=\"stylesheet\">
                                            <li class=\"active\"><a href=\"#tab-body-";
            // line 81
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo (isset($context["tab_body"]) ? $context["tab_body"] : null);
            echo "</a></li>
                                            <li><a href=\"#tab-a-";
            // line 82
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo (isset($context["tab_a"]) ? $context["tab_a"] : null);
            echo "</a></li>
                                            <li><a href=\"#tab-header-";
            // line 83
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo (isset($context["tab_header"]) ? $context["tab_header"] : null);
            echo "</a></li>
                                        </ul>
                                    </div>
                                    <div class=\"col-sm-10\">
                                        <div class=\"tab-content\">
                                            <div class=\"tab-pane active\" id=\"tab-body-";
            // line 88
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-body-color\">";
            // line 90
            echo (isset($context["entry_color"]) ? $context["entry_color"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-body-color\" class=\"jscolor form-control\" name=\"module_octhemeoption_body[";
            // line 92
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][color]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_body"]) ? $context["module_octhemeoption_body"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "color", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-body-font-family\">";
            // line 96
            echo (isset($context["entry_font_family"]) ? $context["entry_font_family"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-body-font-family\" class=\"form-control\" name=\"module_octhemeoption_body[";
            // line 98
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][font_family]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_body"]) ? $context["module_octhemeoption_body"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "font_family", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-body-font-size\">";
            // line 102
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-body-font-size\" class=\"form-control\" name=\"module_octhemeoption_body[";
            // line 104
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_body"]) ? $context["module_octhemeoption_body"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "font_size", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-body-font-weight\">";
            // line 108
            echo (isset($context["entry_font_weight"]) ? $context["entry_font_weight"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-body-font-weight\" class=\"form-control\" name=\"module_octhemeoption_body[";
            // line 110
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][font_weight]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_body"]) ? $context["module_octhemeoption_body"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "font_weight", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-line-height\">";
            // line 114
            echo (isset($context["entry_line_height"]) ? $context["entry_line_height"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-line-height\" class=\"form-control\" name=\"module_octhemeoption_body[";
            // line 116
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][line_height]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_body"]) ? $context["module_octhemeoption_body"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "line_height", array());
            echo "\" />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class=\"tab-pane\" id=\"tab-a-";
            // line 121
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-color\">";
            // line 123
            echo (isset($context["entry_color"]) ? $context["entry_color"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-color\" class=\"jscolor form-control\" name=\"module_octhemeoption_a_tag[";
            // line 125
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][color]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_a_tag"]) ? $context["module_octhemeoption_a_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "color", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-hover-color\">";
            // line 129
            echo (isset($context["entry_hover_color"]) ? $context["entry_hover_color"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-hover-color\" class=\"jscolor form-control\" name=\"module_octhemeoption_a_tag[";
            // line 131
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][hover_color]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_a_tag"]) ? $context["module_octhemeoption_a_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "hover_color", array());
            echo "\" />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class=\"tab-pane\" id=\"tab-header-";
            // line 136
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-hcolor\">";
            // line 138
            echo (isset($context["entry_color"]) ? $context["entry_color"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-hcolor\" class=\"jscolor form-control\" name=\"module_octhemeoption_header_tag[";
            // line 140
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][color]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "color", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-hfont-family\">";
            // line 144
            echo (isset($context["entry_font_family"]) ? $context["entry_font_family"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-hfont-family\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 146
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][font_family]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "font_family", array());
            echo "\" />
                                                    </div>
                                                </div>
                                                <div class=\"form-group\">
                                                    <label class=\"col-sm-2 control-label\" for=\"input-hfont-weight\">";
            // line 150
            echo (isset($context["entry_font_weight"]) ? $context["entry_font_weight"] : null);
            echo "</label>
                                                    <div class=\"col-sm-3\">
                                                        <input type=\"text\" id=\"input-hfont-weight\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 152
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][font_weight]\" value=\"";
            echo $this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "font_weight", array());
            echo "\" />
                                                    </div>
                                                </div>

                                                <ul class=\"nav nav-tabs\">
                                                    <li class=\"active\"><a href=\"#tab-h1-";
            // line 157
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h1";
            echo "</a></li>
                                                    <li><a href=\"#tab-h2-";
            // line 158
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h2";
            echo "</a></li>
                                                    <li><a href=\"#tab-h3-";
            // line 159
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h3";
            echo "</a></li>
                                                    <li><a href=\"#tab-h4-";
            // line 160
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h4";
            echo "</a></li>
                                                    <li><a href=\"#tab-h5-";
            // line 161
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h5";
            echo "</a></li>
                                                    <li><a href=\"#tab-h6-";
            // line 162
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" data-toggle=\"tab\">";
            echo "h6";
            echo "</a></li>
                                                </ul>
                                                <div class=\"tab-content\">
                                                    <div class=\"tab-pane active\" id=\"tab-h1-";
            // line 165
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h1-font-size\">";
            // line 167
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h1-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 169
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h1][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h1", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"tab-pane\" id=\"tab-h2-";
            // line 173
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h2-font-size\">";
            // line 175
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h2-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 177
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h2][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h2", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"tab-pane\" id=\"tab-h3-";
            // line 181
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h3-font-size\">";
            // line 183
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h3-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 185
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h3][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h3", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"tab-pane\" id=\"tab-h4-";
            // line 189
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h4-font-size\">";
            // line 191
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h4-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 193
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h4][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h4", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"tab-pane\" id=\"tab-h5-";
            // line 197
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h5-font-size\">";
            // line 199
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h5-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 201
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h5][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h5", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class=\"tab-pane\" id=\"tab-h6-";
            // line 205
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">
                                                        <div class=\"form-group\">
                                                            <label class=\"col-sm-2 control-label\" for=\"input-h6-font-size\">";
            // line 207
            echo (isset($context["entry_font_size"]) ? $context["entry_font_size"] : null);
            echo "</label>
                                                            <div class=\"col-sm-3\">
                                                                <input type=\"text\" id=\"input-h6-font-size\" class=\"form-control\" name=\"module_octhemeoption_header_tag[";
            // line 209
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "][h6][font_size]\" value=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["module_octhemeoption_header_tag"]) ? $context["module_octhemeoption_header_tag"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array"), "h6", array()), "font_size", array());
            echo "\" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['store'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 220
        echo "                        </div>

                        <div class=\"tab-pane\" id=\"tab-configuration\">
                            <div class=\"form-group\">
                                <label class=\"col-sm-2 control-label\" for=\"input-image\">";
        // line 224
        echo (isset($context["entry_loader_image"]) ? $context["entry_loader_image"] : null);
        echo "</label>
                                <div class=\"col-sm-10\">
                                    <a href=\"\" id=\"thumb-image\" data-toggle=\"image\" class=\"img-thumbnail\"><img src=\"";
        // line 226
        echo (isset($context["thumb"]) ? $context["thumb"] : null);
        echo "\" alt=\"\" title=\"\"  /></a>
                                    <input type=\"hidden\" name=\"module_octhemeoption_loader_img\" value=\"";
        // line 227
        echo (isset($context["module_octhemeoption_loader_img"]) ? $context["module_octhemeoption_loader_img"] : null);
        echo "\" id=\"input-image\" />
                                </div>
                            </div>

                            <div class=\"form-group\">
                                <label class=\"col-sm-2 control-label\" for=\"input-configuration-store\">";
        // line 232
        echo (isset($context["entry_store"]) ? $context["entry_store"] : null);
        echo "</label>
                                <div class=\"col-sm-6\">
                                    <select id=\"input-configuration-store\" class=\"form-control\">
                                        ";
        // line 235
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["stores"]) ? $context["stores"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["store"]) {
            // line 236
            echo "                                            <option value=\"";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" ";
            if (($this->getAttribute($context["store"], "store_id", array()) == 0)) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo $this->getAttribute($context["store"], "name", array());
            echo "</option>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['store'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 238
        echo "                                    </select>
                                </div>
                            </div>

                            ";
        // line 242
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["stores"]) ? $context["stores"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["store"]) {
            // line 243
            echo "                            <div id=\"frm-configuration-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"frm-configuration\">
                                <div class=\"form-group\">
                                    <label class=\"col-sm-2 control-label\" for=\"input-catalog-";
            // line 245
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">";
            echo (isset($context["entry_catalog"]) ? $context["entry_catalog"] : null);
            echo "</label>
                                    <div class=\"col-sm-6\">
                                        <select name=\"module_octhemeoption_catalog[";
            // line 247
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "]\" id=\"input-catalog-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"form-control\">
                                            ";
            // line 248
            if ($this->getAttribute((isset($context["module_octhemeoption_catalog"]) ? $context["module_octhemeoption_catalog"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array")) {
                // line 249
                echo "                                                <option value=\"1\" selected=\"selected\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\">";
                // line 250
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            } else {
                // line 252
                echo "                                                <option value=\"1\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\" selected=\"selected\">";
                // line 253
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            }
            // line 255
            echo "                                        </select>
                                    </div>
                                </div>

                                <div class=\"form-group\">
                                    <label class=\"col-sm-2 control-label\" for=\"input-rotator-";
            // line 260
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">";
            echo (isset($context["entry_rotator"]) ? $context["entry_rotator"] : null);
            echo "</label>
                                    <div class=\"col-sm-6\">
                                        <select name=\"module_octhemeoption_rotator[";
            // line 262
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "]\" id=\"input-rotator-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"form-control\">
                                            ";
            // line 263
            if ($this->getAttribute((isset($context["module_octhemeoption_rotator"]) ? $context["module_octhemeoption_rotator"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array")) {
                // line 264
                echo "                                                <option value=\"1\" selected=\"selected\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\">";
                // line 265
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            } else {
                // line 267
                echo "                                                <option value=\"1\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\" selected=\"selected\">";
                // line 268
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            }
            // line 270
            echo "                                        </select>
                                    </div>
                                </div>

                                <div class=\"form-group\">
                                    <label class=\"col-sm-2 control-label\" for=\"input-quickview-";
            // line 275
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\">";
            echo (isset($context["entry_quickview"]) ? $context["entry_quickview"] : null);
            echo "</label>
                                    <div class=\"col-sm-6\">
                                        <select name=\"module_octhemeoption_quickview[";
            // line 277
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "]\" id=\"input-quickview-";
            echo $this->getAttribute($context["store"], "store_id", array());
            echo "\" class=\"form-control\">
                                            ";
            // line 278
            if ($this->getAttribute((isset($context["module_octhemeoption_quickview"]) ? $context["module_octhemeoption_quickview"] : null), $this->getAttribute($context["store"], "store_id", array()), array(), "array")) {
                // line 279
                echo "                                                <option value=\"1\" selected=\"selected\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\">";
                // line 280
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            } else {
                // line 282
                echo "                                                <option value=\"1\">";
                echo (isset($context["text_enabled"]) ? $context["text_enabled"] : null);
                echo "</option>
                                                <option value=\"0\" selected=\"selected\">";
                // line 283
                echo (isset($context["text_disabled"]) ? $context["text_disabled"] : null);
                echo "</option>
                                            ";
            }
            // line 285
            echo "                                        </select>
                                    </div>
                                </div>
                            </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['store'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 290
        echo "

                        </div>

                        <div class=\"tab-pane\" id=\"tab-database\">
                            <div class=\"form-group\">
                                <label class=\"col-sm-2 control-label\" for=\"input-theme\">";
        // line 296
        echo (isset($context["entry_theme_database"]) ? $context["entry_theme_database"] : null);
        echo "</label>
                                <div class=\"col-sm-10\">
                                    <div class=\"row\">
                                        <div class=\"col-sm-6\">
                                            <select id=\"input-theme\" class=\"form-control\" name=\"file\">
                                            ";
        // line 301
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["database"]) ? $context["database"] : null));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            // line 302
            echo "                                                <option value=\"";
            echo $context["key"];
            echo "\">";
            echo $context["value"];
            echo "</option>
                                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 304
        echo "                                            </select>
                                        </div>
                                        <div class=\"col-sm-6\">
                                            <button type=\"button\" id=\"button-import\" class=\"btn btn-primary\"><i class=\"fa fa-upload\"></i> ";
        // line 307
        echo (isset($context["button_import"]) ? $context["button_import"] : null);
        echo "</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type=\"text/javascript\">
    \$(document).ready(function () {
        // Configuration of Stores
        \$('.frm-configuration').hide();
        \$('#frm-configuration-0').show();
        \$('#input-configuration-store').change(function () {
            var store_id = \$(this).val();
            \$('.frm-configuration').hide();
            \$('#frm-configuration-' + store_id).show();
        });

        // Stylesheet of Stores
        \$('.frm-stylesheet').hide();
        \$('#frm-stylesheet-0').show();
        \$('#input-stylesheet-store').change(function () {
            var store_id = \$(this).val();
            \$('.frm-stylesheet').hide();
            \$('#frm-stylesheet-' + store_id).show();
        });

        // Enable / Disable Settings
        \$('.stylesheet-settings').hide();
        var style_selection = \$('.style-status');
        style_selection.each(function () {
            var store_id = \$(this).data('id');
            var status = parseInt(\$('#input-status-' + store_id).val());

            if(status === 1) {
                \$('#stylesheet-settings-' + store_id).show();
            } else {
                \$('#stylesheet-settings-' + store_id).hide();
            }
        });

        style_selection.change(function () {
            var store_id = \$(this).data('id');
            var status = parseInt(\$('#input-status-' + store_id).val());

            if(status === 1) {
                \$('#stylesheet-settings-' + store_id).show();
            } else {
                \$('#stylesheet-settings-' + store_id).hide();
            }
        });
    });
</script>

<script type=\"text/javascript\"><!--
    \$('#button-import').on('click', function() {

        \$('#form-data input[name=\\'file\\']').val(\$('#input-theme').val());

        \$('#form-data').submit();
    });
    //--></script>
";
        // line 375
        echo (isset($context["footer"]) ? $context["footer"] : null);
    }

    public function getTemplateName()
    {
        return "extension/module/octhemeoption.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  867 => 375,  796 => 307,  791 => 304,  780 => 302,  776 => 301,  768 => 296,  760 => 290,  750 => 285,  745 => 283,  740 => 282,  735 => 280,  730 => 279,  728 => 278,  722 => 277,  715 => 275,  708 => 270,  703 => 268,  698 => 267,  693 => 265,  688 => 264,  686 => 263,  680 => 262,  673 => 260,  666 => 255,  661 => 253,  656 => 252,  651 => 250,  646 => 249,  644 => 248,  638 => 247,  631 => 245,  625 => 243,  621 => 242,  615 => 238,  600 => 236,  596 => 235,  590 => 232,  582 => 227,  578 => 226,  573 => 224,  567 => 220,  548 => 209,  543 => 207,  538 => 205,  529 => 201,  524 => 199,  519 => 197,  510 => 193,  505 => 191,  500 => 189,  491 => 185,  486 => 183,  481 => 181,  472 => 177,  467 => 175,  462 => 173,  453 => 169,  448 => 167,  443 => 165,  435 => 162,  429 => 161,  423 => 160,  417 => 159,  411 => 158,  405 => 157,  395 => 152,  390 => 150,  381 => 146,  376 => 144,  367 => 140,  362 => 138,  357 => 136,  347 => 131,  342 => 129,  333 => 125,  328 => 123,  323 => 121,  313 => 116,  308 => 114,  299 => 110,  294 => 108,  285 => 104,  280 => 102,  271 => 98,  266 => 96,  257 => 92,  252 => 90,  247 => 88,  237 => 83,  231 => 82,  225 => 81,  219 => 78,  213 => 74,  208 => 72,  203 => 71,  198 => 69,  193 => 68,  191 => 67,  183 => 66,  176 => 64,  170 => 62,  166 => 61,  160 => 57,  145 => 55,  141 => 54,  135 => 51,  126 => 45,  122 => 44,  118 => 43,  113 => 41,  106 => 37,  100 => 34,  96 => 32,  88 => 28,  85 => 27,  77 => 23,  74 => 22,  66 => 18,  64 => 17,  58 => 13,  47 => 11,  43 => 10,  38 => 8,  32 => 7,  28 => 6,  19 => 1,);
    }
}
/* {{ header }}{{ column_left }}*/
/* <div id="content">*/
/*     <div class="page-header">*/
/*         <div class="container-fluid">*/
/*             <div class="pull-right">*/
/*                 <button type="submit" form="form-octhemeoption" data-toggle="tooltip" title="{{ button_save }}" class="btn btn-primary"><i class="fa fa-save"></i></button>*/
/*                 <a href="{{ cancel }}" data-toggle="tooltip" title="{{ button_cancel }}" class="btn btn-default"><i class="fa fa-reply"></i></a></div>*/
/*             <h1>{{ heading_title }}</h1>*/
/*             <ul class="breadcrumb">*/
/*                 {% for breadcrumb in breadcrumbs %}*/
/*                     <li><a href="{{ breadcrumb.href }}">{{ breadcrumb.text }}</a></li>*/
/*                 {% endfor %}*/
/*             </ul>*/
/*         </div>*/
/*     </div>*/
/*     <div class="container-fluid">*/
/*         {% if error_warning %}*/
/*             <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ error_warning }}*/
/*                 <button type="button" class="close" data-dismiss="alert">&times;</button>*/
/*             </div>*/
/*         {% endif %}*/
/*         {% if error_load_file %}*/
/*             <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ error_load_file }}*/
/*                 <button type="button" class="close" data-dismiss="alert">&times;</button>*/
/*             </div>*/
/*         {% endif %}*/
/*         {% if success %}*/
/*             <div class="alert alert-success alert-dismissible"><i class="fa fa-check-circle"></i> {{ success }}*/
/*                 <button type="button" class="close" data-dismiss="alert">&times;</button>*/
/*             </div>*/
/*         {% endif %}*/
/*         <div class="panel panel-default">*/
/*             <div class="panel-heading">*/
/*                 <h3 class="panel-title"><i class="fa fa-pencil"></i>{{ text_edit }}</h3>*/
/*             </div>*/
/*             <div class="panel-body">*/
/*                 <form action="{{ action_import }}" method="post" enctype="multipart/form-data" id="form-data" class="form-horizontal">*/
/*                     <input type="hidden" name="file" />*/
/*                 </form>*/
/* */
/*                 <form action="{{ action }}" method="post" enctype="multipart/form-data" id="form-octhemeoption" class="form-horizontal">*/
/*                     <ul class="nav nav-tabs">*/
/*                         <li class="active"><a href="#tab-stylesheet" data-toggle="tab">{{ tab_stylesheet }}</a></li>*/
/*                         <li><a href="#tab-configuration" data-toggle="tab">{{ tab_configuration }}</a></li>*/
/*                         <li><a href="#tab-database" data-toggle="tab">{{ tab_backup }}</a></li>*/
/*                     </ul>*/
/* */
/*                     <div class="tab-content">*/
/*                         <div class="tab-pane active" id="tab-stylesheet">*/
/*                             <div class="form-group">*/
/*                                 <label class="col-sm-2 control-label" for="input-stylesheet-store">{{ entry_store }}</label>*/
/*                                 <div class="col-sm-6">*/
/*                                     <select id="input-stylesheet-store" class="form-control">*/
/*                                         {% for store in stores %}*/
/*                                             <option value="{{ store.store_id }}" {% if(store.store_id == 0) %}selected="selected"{% endif %}>{{ store.name }}</option>*/
/*                                         {% endfor %}*/
/*                                     </select>*/
/*                                 </div>*/
/*                             </div>*/
/* */
/*                             {% for store in stores %}*/
/*                             <div id="frm-stylesheet-{{ store.store_id }}" class="frm-stylesheet">*/
/*                                 <div class="form-group">*/
/*                                     <label class="col-sm-2 control-label" for="input-status-{{ store.store_id }}">{{ entry_status }}</label>*/
/*                                     <div class="col-sm-6">*/
/*                                         <select name="module_octhemeoption_status[{{ store.store_id }}]" id="input-status-{{ store.store_id }}" data-id="{{ store.store_id }}" class="form-control style-status">*/
/*                                             {% if module_octhemeoption_status[store.store_id] %}*/
/*                                                 <option value="1" selected="selected">{{ text_enabled }}</option>*/
/*                                                 <option value="0">{{ text_disabled }}</option>*/
/*                                             {% else %}*/
/*                                                 <option value="1">{{ text_enabled }}</option>*/
/*                                                 <option value="0" selected="selected">{{ text_disabled }}</option>*/
/*                                             {% endif %}*/
/*                                         </select>*/
/*                                     </div>*/
/*                                 </div>*/
/* */
/*                                 <div class="row stylesheet-settings" id="stylesheet-settings-{{ store.store_id }}">*/
/*                                     <div class="col-sm-2">*/
/*                                         <ul class="nav nav-pills nav-stacked" id="stylesheet">*/
/*                                             <li class="active"><a href="#tab-body-{{ store.store_id }}" data-toggle="tab">{{ tab_body }}</a></li>*/
/*                                             <li><a href="#tab-a-{{ store.store_id }}" data-toggle="tab">{{ tab_a }}</a></li>*/
/*                                             <li><a href="#tab-header-{{ store.store_id }}" data-toggle="tab">{{ tab_header }}</a></li>*/
/*                                         </ul>*/
/*                                     </div>*/
/*                                     <div class="col-sm-10">*/
/*                                         <div class="tab-content">*/
/*                                             <div class="tab-pane active" id="tab-body-{{ store.store_id }}">*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-body-color">{{ entry_color }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-body-color" class="jscolor form-control" name="module_octhemeoption_body[{{ store.store_id }}][color]" value="{{ module_octhemeoption_body[store.store_id].color }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-body-font-family">{{ entry_font_family }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-body-font-family" class="form-control" name="module_octhemeoption_body[{{ store.store_id }}][font_family]" value="{{ module_octhemeoption_body[store.store_id].font_family }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-body-font-size">{{ entry_font_size }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-body-font-size" class="form-control" name="module_octhemeoption_body[{{ store.store_id }}][font_size]" value="{{ module_octhemeoption_body[store.store_id].font_size }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-body-font-weight">{{ entry_font_weight }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-body-font-weight" class="form-control" name="module_octhemeoption_body[{{ store.store_id }}][font_weight]" value="{{ module_octhemeoption_body[store.store_id].font_weight }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-line-height">{{ entry_line_height }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-line-height" class="form-control" name="module_octhemeoption_body[{{ store.store_id }}][line_height]" value="{{ module_octhemeoption_body[store.store_id].line_height }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                             </div>*/
/* */
/*                                             <div class="tab-pane" id="tab-a-{{ store.store_id }}">*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-color">{{ entry_color }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-color" class="jscolor form-control" name="module_octhemeoption_a_tag[{{ store.store_id }}][color]" value="{{ module_octhemeoption_a_tag[store.store_id].color }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-hover-color">{{ entry_hover_color }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-hover-color" class="jscolor form-control" name="module_octhemeoption_a_tag[{{ store.store_id }}][hover_color]" value="{{ module_octhemeoption_a_tag[store.store_id].hover_color }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                             </div>*/
/* */
/*                                             <div class="tab-pane" id="tab-header-{{ store.store_id }}">*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-hcolor">{{ entry_color }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-hcolor" class="jscolor form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][color]" value="{{ module_octhemeoption_header_tag[store.store_id].color }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-hfont-family">{{ entry_font_family }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-hfont-family" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][font_family]" value="{{ module_octhemeoption_header_tag[store.store_id].font_family }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                                 <div class="form-group">*/
/*                                                     <label class="col-sm-2 control-label" for="input-hfont-weight">{{ entry_font_weight }}</label>*/
/*                                                     <div class="col-sm-3">*/
/*                                                         <input type="text" id="input-hfont-weight" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][font_weight]" value="{{ module_octhemeoption_header_tag[store.store_id].font_weight }}" />*/
/*                                                     </div>*/
/*                                                 </div>*/
/* */
/*                                                 <ul class="nav nav-tabs">*/
/*                                                     <li class="active"><a href="#tab-h1-{{ store.store_id }}" data-toggle="tab">{{ 'h1' }}</a></li>*/
/*                                                     <li><a href="#tab-h2-{{ store.store_id }}" data-toggle="tab">{{ 'h2' }}</a></li>*/
/*                                                     <li><a href="#tab-h3-{{ store.store_id }}" data-toggle="tab">{{ 'h3' }}</a></li>*/
/*                                                     <li><a href="#tab-h4-{{ store.store_id }}" data-toggle="tab">{{ 'h4' }}</a></li>*/
/*                                                     <li><a href="#tab-h5-{{ store.store_id }}" data-toggle="tab">{{ 'h5' }}</a></li>*/
/*                                                     <li><a href="#tab-h6-{{ store.store_id }}" data-toggle="tab">{{ 'h6' }}</a></li>*/
/*                                                 </ul>*/
/*                                                 <div class="tab-content">*/
/*                                                     <div class="tab-pane active" id="tab-h1-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h1-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h1-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h1][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h1.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                     <div class="tab-pane" id="tab-h2-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h2-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h2-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h2][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h2.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                     <div class="tab-pane" id="tab-h3-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h3-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h3-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h3][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h3.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                     <div class="tab-pane" id="tab-h4-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h4-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h4-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h4][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h4.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                     <div class="tab-pane" id="tab-h5-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h5-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h5-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h5][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h5.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                     <div class="tab-pane" id="tab-h6-{{ store.store_id }}">*/
/*                                                         <div class="form-group">*/
/*                                                             <label class="col-sm-2 control-label" for="input-h6-font-size">{{ entry_font_size }}</label>*/
/*                                                             <div class="col-sm-3">*/
/*                                                                 <input type="text" id="input-h6-font-size" class="form-control" name="module_octhemeoption_header_tag[{{ store.store_id }}][h6][font_size]" value="{{ module_octhemeoption_header_tag[store.store_id].h6.font_size }}" />*/
/*                                                             </div>*/
/*                                                         </div>*/
/*                                                     </div>*/
/*                                                 </div>*/
/*                                             </div>*/
/*                                         </div>*/
/*                                     </div>*/
/*                                 </div>*/
/*                             </div>*/
/*                             {% endfor %}*/
/*                         </div>*/
/* */
/*                         <div class="tab-pane" id="tab-configuration">*/
/*                             <div class="form-group">*/
/*                                 <label class="col-sm-2 control-label" for="input-image">{{ entry_loader_image }}</label>*/
/*                                 <div class="col-sm-10">*/
/*                                     <a href="" id="thumb-image" data-toggle="image" class="img-thumbnail"><img src="{{ thumb }}" alt="" title=""  /></a>*/
/*                                     <input type="hidden" name="module_octhemeoption_loader_img" value="{{ module_octhemeoption_loader_img }}" id="input-image" />*/
/*                                 </div>*/
/*                             </div>*/
/* */
/*                             <div class="form-group">*/
/*                                 <label class="col-sm-2 control-label" for="input-configuration-store">{{ entry_store }}</label>*/
/*                                 <div class="col-sm-6">*/
/*                                     <select id="input-configuration-store" class="form-control">*/
/*                                         {% for store in stores %}*/
/*                                             <option value="{{ store.store_id }}" {% if(store.store_id == 0) %}selected="selected"{% endif %}>{{ store.name }}</option>*/
/*                                         {% endfor %}*/
/*                                     </select>*/
/*                                 </div>*/
/*                             </div>*/
/* */
/*                             {% for store in stores %}*/
/*                             <div id="frm-configuration-{{ store.store_id }}" class="frm-configuration">*/
/*                                 <div class="form-group">*/
/*                                     <label class="col-sm-2 control-label" for="input-catalog-{{ store.store_id }}">{{ entry_catalog }}</label>*/
/*                                     <div class="col-sm-6">*/
/*                                         <select name="module_octhemeoption_catalog[{{ store.store_id }}]" id="input-catalog-{{ store.store_id }}" class="form-control">*/
/*                                             {% if module_octhemeoption_catalog[store.store_id] %}*/
/*                                                 <option value="1" selected="selected">{{ text_enabled }}</option>*/
/*                                                 <option value="0">{{ text_disabled }}</option>*/
/*                                             {% else %}*/
/*                                                 <option value="1">{{ text_enabled }}</option>*/
/*                                                 <option value="0" selected="selected">{{ text_disabled }}</option>*/
/*                                             {% endif %}*/
/*                                         </select>*/
/*                                     </div>*/
/*                                 </div>*/
/* */
/*                                 <div class="form-group">*/
/*                                     <label class="col-sm-2 control-label" for="input-rotator-{{ store.store_id }}">{{ entry_rotator }}</label>*/
/*                                     <div class="col-sm-6">*/
/*                                         <select name="module_octhemeoption_rotator[{{ store.store_id }}]" id="input-rotator-{{ store.store_id }}" class="form-control">*/
/*                                             {% if module_octhemeoption_rotator[store.store_id] %}*/
/*                                                 <option value="1" selected="selected">{{ text_enabled }}</option>*/
/*                                                 <option value="0">{{ text_disabled }}</option>*/
/*                                             {% else %}*/
/*                                                 <option value="1">{{ text_enabled }}</option>*/
/*                                                 <option value="0" selected="selected">{{ text_disabled }}</option>*/
/*                                             {% endif %}*/
/*                                         </select>*/
/*                                     </div>*/
/*                                 </div>*/
/* */
/*                                 <div class="form-group">*/
/*                                     <label class="col-sm-2 control-label" for="input-quickview-{{ store.store_id }}">{{ entry_quickview }}</label>*/
/*                                     <div class="col-sm-6">*/
/*                                         <select name="module_octhemeoption_quickview[{{ store.store_id }}]" id="input-quickview-{{ store.store_id }}" class="form-control">*/
/*                                             {% if module_octhemeoption_quickview[store.store_id] %}*/
/*                                                 <option value="1" selected="selected">{{ text_enabled }}</option>*/
/*                                                 <option value="0">{{ text_disabled }}</option>*/
/*                                             {% else %}*/
/*                                                 <option value="1">{{ text_enabled }}</option>*/
/*                                                 <option value="0" selected="selected">{{ text_disabled }}</option>*/
/*                                             {% endif %}*/
/*                                         </select>*/
/*                                     </div>*/
/*                                 </div>*/
/*                             </div>*/
/*                             {% endfor %}*/
/* */
/* */
/*                         </div>*/
/* */
/*                         <div class="tab-pane" id="tab-database">*/
/*                             <div class="form-group">*/
/*                                 <label class="col-sm-2 control-label" for="input-theme">{{ entry_theme_database }}</label>*/
/*                                 <div class="col-sm-10">*/
/*                                     <div class="row">*/
/*                                         <div class="col-sm-6">*/
/*                                             <select id="input-theme" class="form-control" name="file">*/
/*                                             {% for key, value in database %}*/
/*                                                 <option value="{{ key }}">{{ value }}</option>*/
/*                                             {% endfor %}*/
/*                                             </select>*/
/*                                         </div>*/
/*                                         <div class="col-sm-6">*/
/*                                             <button type="button" id="button-import" class="btn btn-primary"><i class="fa fa-upload"></i> {{ button_import }}</button>*/
/*                                         </div>*/
/*                                     </div>*/
/*                                 </div>*/
/*                             </div>*/
/*                         </div>*/
/*                     </div>*/
/*                 </form>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
/* */
/* <script type="text/javascript">*/
/*     $(document).ready(function () {*/
/*         // Configuration of Stores*/
/*         $('.frm-configuration').hide();*/
/*         $('#frm-configuration-0').show();*/
/*         $('#input-configuration-store').change(function () {*/
/*             var store_id = $(this).val();*/
/*             $('.frm-configuration').hide();*/
/*             $('#frm-configuration-' + store_id).show();*/
/*         });*/
/* */
/*         // Stylesheet of Stores*/
/*         $('.frm-stylesheet').hide();*/
/*         $('#frm-stylesheet-0').show();*/
/*         $('#input-stylesheet-store').change(function () {*/
/*             var store_id = $(this).val();*/
/*             $('.frm-stylesheet').hide();*/
/*             $('#frm-stylesheet-' + store_id).show();*/
/*         });*/
/* */
/*         // Enable / Disable Settings*/
/*         $('.stylesheet-settings').hide();*/
/*         var style_selection = $('.style-status');*/
/*         style_selection.each(function () {*/
/*             var store_id = $(this).data('id');*/
/*             var status = parseInt($('#input-status-' + store_id).val());*/
/* */
/*             if(status === 1) {*/
/*                 $('#stylesheet-settings-' + store_id).show();*/
/*             } else {*/
/*                 $('#stylesheet-settings-' + store_id).hide();*/
/*             }*/
/*         });*/
/* */
/*         style_selection.change(function () {*/
/*             var store_id = $(this).data('id');*/
/*             var status = parseInt($('#input-status-' + store_id).val());*/
/* */
/*             if(status === 1) {*/
/*                 $('#stylesheet-settings-' + store_id).show();*/
/*             } else {*/
/*                 $('#stylesheet-settings-' + store_id).hide();*/
/*             }*/
/*         });*/
/*     });*/
/* </script>*/
/* */
/* <script type="text/javascript"><!--*/
/*     $('#button-import').on('click', function() {*/
/* */
/*         $('#form-data input[name=\'file\']').val($('#input-theme').val());*/
/* */
/*         $('#form-data').submit();*/
/*     });*/
/*     //--></script>*/
/* {{ footer }}*/
